package com.example.maelaniayuningsih.andro;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class tambah_data extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_data);
    }
}
